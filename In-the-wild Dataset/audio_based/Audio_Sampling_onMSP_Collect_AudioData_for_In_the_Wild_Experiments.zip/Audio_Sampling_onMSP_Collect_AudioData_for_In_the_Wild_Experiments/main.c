/*
 * main.c
 *
 *  created on: May 3, 2019
 *      Author: Yubo-ASUS
 */



#include "application/global.h"
#include "string.h"

// record the current connected capacitor number
//#pragma PERSISTENT(SW_Mode)
//SW_Mode_t SW_Mode = DEFAULT;



//uint8_t ModelTrainPinValue;
//uint8_t DebugOntheFly = 0;
//uint8_t restart = 1;


/* which mode you are running: learning or testing
 * learning phase (relating to Phase-1 and Phase-2) : running RL until it converges
 * testing phase (relating to Phase-3): after RL is converged, running converged RL to test its performance in event detection
 * */
//uint8_t learning = 1;

void initClock(void);
void initGPIO(void);


void main(){

    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer
    initClock();
    initGPIO();

    while(1){
        runSampling_Audio();

    }




    __bis_SR_register(LPM3_bits + GIE);




}






void initClock()
{
    // Configure one FRAM waitstate as required by the device datasheet for MCLK
    // operation beyond 8MHz _before_ configuring the clock system.
    FRCTL0 = FRCTLPW | NWAITS_1;  // uncomment this line if >8MHz

    // the DriverLib version of clock systems setup for clock
    CS_setDCOFreq(CS_DCORSEL_0, CS_DCOFSEL_6);   // set DCO to 8 MHz
    CS_initClockSignal(CS_ACLK, CS_VLOCLK_SELECT, CS_CLOCK_DIVIDER_1);  // ACLK to VLO(9.4KHz for FR5994), divided by 1
    CS_initClockSignal(CS_MCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_1);  // MCLK to DCO, divided by 1
    CS_initClockSignal(CS_SMCLK, CS_DCOCLK_SELECT, CS_CLOCK_DIVIDER_2); // SMCLK to DCO, divided by 2 -> 4MHz
    CS_turnOffLFXT();  // Stops the LFXT oscillator, save power
    CS_turnOffHFXT();  // Stops the HFXT oscillator, save power
}



void initGPIO()
{

    // Configure GPIO
    // save energy
    PADIR=0xffff; PAOUT=0x0000; // Ports 1 and 2
    PBDIR=0xffff; PBOUT=0x0000; // Ports 3 and 4
    PCDIR=0xffff; PCOUT=0x0000; // Ports 5 and 6
    PDDIR=0xffff; PDOUT=0x0000; // Ports 7 and 8
    PJDIR=0xff; PJOUT=0x00;     // Port J


    // for on board LEDs, green and red LEDs
    GPIO_setAsOutputPin(REDLED);
    GPIO_setAsOutputPin(GREENLED);



    // Disable the GPIO power-on default high-impedance mode to activate
    // previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;
}


